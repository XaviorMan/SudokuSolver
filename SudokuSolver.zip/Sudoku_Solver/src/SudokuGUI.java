import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class SudokuGUI extends Application {
    private static final int SIZE = 9;
    private TextField[][] textFields = new TextField[SIZE][SIZE];

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Sudoku Solver");

        GridPane gridPane = createSudokuGrid();
        Button solveButton = new Button("Solve");
        solveButton.setOnAction(e -> solveSudoku());

        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.add(gridPane, 0, 0);
        root.add(solveButton, 0, 1);

        Scene scene = new Scene(root, 300, 350);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private GridPane createSudokuGrid() {
        GridPane gridPane = new GridPane();
        gridPane.setHgap(2);
        gridPane.setVgap(2);
        gridPane.setStyle("-fx-border-color: black; -fx-border-width: 2;");

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                TextField textField = new TextField();
                textField.setPrefSize(30, 30);
                textField.setAlignment(Pos.CENTER);
                textFields[i][j] = textField;

                textField.textProperty().addListener((observable, oldValue, newValue) -> {
                    if (!newValue.matches("\\d?")) {
                        textField.setText(oldValue);
                    }
                });

                int subgridRow = i / 3;
                int subgridCol = j / 3;

                gridPane.add(textField, j % 3 + subgridCol * 3, i % 3 + subgridRow * 3);
            }
        }

        return gridPane;
    }

    private void solveSudoku() {
        int[][] grid = getCurrentGridState();

        boolean isSolved = SudokuSolver.solveSudoku(grid);

        if (isSolved) {
            updateGridOnUI(grid);
        } else {
            showAlert("Invalid Sudoku", "The provided Sudoku puzzle is unsolvable.");
        }
    }

    private int[][] getCurrentGridState() {
        int[][] grid = new int[SIZE][SIZE];

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                String value = textFields[i][j].getText();
                grid[i][j] = value.isEmpty() ? 0 : Integer.parseInt(value);
            }
        }

        return grid;
    }

    private void updateGridOnUI(int[][] grid) {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                textFields[i][j].setText(String.valueOf(grid[i][j]));
            }
        }
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
