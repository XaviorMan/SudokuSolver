import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class SudokuSolverTest {

    @Test
    public void testUnsolvableSudoku() {
        int[][] unsolvableSudoku = {
                {5, 3, 0, 0, 7, 0, 0, 0, 0},
                {6, 3, 0, 1, 9, 5, 0, 0, 0},
                {0, 9, 8, 0, 0, 0, 0, 6, 0},
                {8, 0, 0, 0, 6, 0, 0, 0, 3},
                {4, 0, 0, 8, 0, 3, 0, 0, 1},
                {7, 0, 0, 0, 2, 0, 0, 0, 6},
                {0, 6, 0, 0, 0, 0, 2, 8, 0},
                {0, 0, 0, 4, 1, 9, 0, 0, 5},
                {0, 0, 0, 0, 8, 0, 0, 7, 9}
        };

        System.out.println("Original Sudoku:");
        printSudoku(unsolvableSudoku);

        boolean result = SudokuSolver.solveSudoku(unsolvableSudoku);

        System.out.println("Solved Sudoku:");
        printSudoku(unsolvableSudoku);

        assertFalse(result);
    }
        
        @Test
        public void testSolvableSudoku() {
            int[][] solvableSudoku = {
                    {5, 3, 0, 0, 7, 0, 0, 0, 0},
                    {6, 0, 0, 1, 9, 5, 0, 0, 0},
                    {0, 9, 8, 0, 0, 0, 0, 6, 0},
                    {8, 0, 0, 0, 6, 0, 0, 0, 3},
                    {4, 0, 0, 8, 0, 3, 0, 0, 1},
                    {7, 0, 0, 0, 2, 0, 0, 0, 6},
                    {0, 6, 0, 0, 0, 0, 2, 8, 0},
                    {0, 0, 0, 4, 1, 9, 0, 0, 5},
                    {0, 0, 0, 0, 8, 0, 0, 7, 9}
            };

            System.out.println("Original Sudoku:");
            printSudoku(solvableSudoku);

            boolean solveResult = SudokuSolver.solveSudoku(solvableSudoku);

            System.out.println("Solved Sudoku:");
            printSudoku(solvableSudoku);

            assertTrue(solveResult);
        }

    private void printSudoku(int[][] sudoku) {
        for (int[] row : sudoku) {
            for (int num : row) {
                System.out.print(num + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
}