import java.util.Random;

class SudokuGeneratorTwo {
    private static final int SIZE = 9;
    private static final int MIN_CLUES = 17;
    private static final int MAX_CLUES = 20;
    private static final Random RANDOM = new Random();

    public static int[][] generateRandomPuzzle() {
        int[][] puzzle = new int[SIZE][SIZE];
        solveRandomPuzzle(puzzle);
        removeNumbers(puzzle);
        return puzzle;
    }

    private static boolean solveRandomPuzzle(int[][] puzzle) {
        return SudokuSolver.solveSudoku(puzzle); 
    }

    private static void removeNumbers(int[][] puzzle) {
        int cluesToRemove = SIZE * SIZE - RANDOM.nextInt(MAX_CLUES - MIN_CLUES + 1) - MIN_CLUES;
        while (cluesToRemove > 0) {
            int row = RANDOM.nextInt(SIZE);
            int col = RANDOM.nextInt(SIZE);
            if (puzzle[row][col] != 0) {
                puzzle[row][col] = 0;
                cluesToRemove--;
            }
        }
    }
}