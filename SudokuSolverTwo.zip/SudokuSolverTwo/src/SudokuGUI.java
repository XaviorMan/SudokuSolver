import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class SudokuGUI extends Application {
    private static final int SIZE = 9;
    private TextField[][] textFields = new TextField[SIZE][SIZE];
    private RadioButton backtrackingRadio, bruteForceRadio;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Sudoku Solver");

        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(2);
        gridPane.setVgap(2);
        gridPane.setStyle("-fx-border-color: black; -fx-border-width: 2;");

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                TextField textField = new TextField();
                textField.setPrefSize(30, 30);
                textField.setAlignment(Pos.CENTER);
                textField.textProperty().addListener((observable, oldValue, newValue) -> {
                    if (!newValue.matches("\\d?")) {
                        textField.setText(oldValue);
                    }
                });
                textFields[i][j] = textField;

                int subgridRow = i / 3;
                int subgridCol = j / 3;

                gridPane.add(textField, j % 3 + subgridCol * 3, i % 3 + subgridRow * 3);
            }
        }

        // Define colors for the subgrids
        String[] subgridColors = {"#FFA07A", "#98FB98", "#87CEFA", "#F0E68C", "#AFEEEE", "#B0C4DE", "#FFDAB9", "#DDA0DD", "#D3D3D3"};

        // Assign colors to the 3x3 subgrids
        for (int i = 0; i < SIZE / 3; i++) {
            for (int j = 0; j < SIZE / 3; j++) {
                GridPane subgrid = new GridPane();
                subgrid.setAlignment(Pos.CENTER);
                subgrid.setHgap(2);
                subgrid.setVgap(2);
                subgrid.setStyle("-fx-background-color: " + subgridColors[i * (SIZE / 3) + j] + ";");

                for (int k = 0; k < 3; k++) {
                    for (int l = 0; l < 3; l++) {
                        int rowIndex = i * 3 + k;
                        int colIndex = j * 3 + l;
                        subgrid.add(textFields[rowIndex][colIndex], l, k);
                    }
                }

                gridPane.add(subgrid, j * 3, i * 3);
            }
        }

        backtrackingRadio = new RadioButton("Backtracking");
        bruteForceRadio = new RadioButton("Brute Force");
        ToggleGroup solvingMethodGroup = new ToggleGroup();
        backtrackingRadio.setToggleGroup(solvingMethodGroup);
        bruteForceRadio.setToggleGroup(solvingMethodGroup);
        backtrackingRadio.setSelected(true); // Default selection

        Button solveButton = new Button("Solve");
        solveButton.setOnAction(e -> {
            int[][] puzzle = extractGridFromUI();
            boolean solved;
            if (backtrackingRadio.isSelected()) {
                solved = SudokuSolver.solveSudokuBacktracking(puzzle);
            } else {
                solved = SudokuSolver.solveSudokuBruteForce(puzzle);
            }

            if (solved) {
                updateGridOnUI(puzzle);
            } else {
                showAlert("Unsolvable", "The Sudoku puzzle cannot be solved.");
            }
        });

        Button generateButton = new Button("Generate Puzzle");
        generateButton.setOnAction(e -> {
            int[][] puzzle = SudokuGeneratorTwo.generateRandomPuzzle();
            updateGridOnUI(puzzle);
        });

        Button clearButton = new Button("Clear");
        clearButton.setOnAction(e -> {
            for (TextField[] row : textFields) {
                for (TextField textField : row) {
                    textField.clear();
                }
            }
        });

        GridPane root = new GridPane();
        root.setAlignment(Pos.CENTER);
        root.add(gridPane, 0, 0);
        root.add(solveButton, 0, 1);
        root.add(generateButton, 0, 2);
        root.add(clearButton, 0, 3);
        root.add(backtrackingRadio, 0, 4);
        root.add(bruteForceRadio, 0, 5);

        Scene scene = new Scene(root, 300, 480);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void updateGridOnUI(int[][] grid) {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                textFields[i][j].setText(grid[i][j] == 0 ? "" : String.valueOf(grid[i][j]));
            }
        }
    }

    private int[][] extractGridFromUI() {
        int[][] grid = new int[SIZE][SIZE];
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                String text = textFields[i][j].getText();
                grid[i][j] = text.isEmpty() ? 0 : Integer.parseInt(text);
            }
        }
        return grid;
    }
}